import { useState } from 'react';

function ToDoItem({ task, toggleComplete, deleteTask, editTask }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editText, setEditText] = useState(task.text);

  const handleEdit = () => {
    editTask(task.id, editText);
    setIsEditing(false);
  };

  return (
    <li className="flex items-center justify-between bg-white p-3 mb-2 shadow rounded">
      {isEditing ? (
        <input 
          type="text"
          className="flex-1 p-2 border border-gray-300 mr-2"
          value={editText}
          onChange={(e) => setEditText(e.target.value)}
        />
      ) : (
        <span 
          className={task.completed ? 'line-through text-gray-500' : ''}
          onClick={() => toggleComplete(task.id)}
        >
          {task.text}
        </span>
      )}
      <div className="flex space-x-2">
        {isEditing ? (
          <button className="bg-green-500 text-white px-3 py-1 rounded" onClick={handleEdit}>
            Save
          </button>
        ) : (
          <button className="bg-yellow-500 text-white px-3 py-1 rounded" onClick={() => setIsEditing(true)}>
            Edit <br/>
          </button>
        )}
        <button className="bg-red-500 text-white px-3 py-1 rounded" onClick={() => deleteTask(task.id)}>
          Delete
        </button>
      </div>
    </li>
  );
}

export default ToDoItem;