import { useState } from 'react';
import ToDoItem from './ToDoItem';

function ToDoList({ tasks, addTask, toggleComplete, deleteTask, editTask }) {
  const [newTask, setNewTask] = useState('');

  const handleAddTask = () => {
    if (newTask.trim()) {
      addTask(newTask);
      setNewTask('');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex mb-4">
        <input 
          type="text"
          className="flex-1 p-2 border border-gray-300 rounded-l"
          placeholder="Add a new task..."
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
        />
        <button 
          className="bg-blue-500 text-white p-2 rounded-r"
          onClick={handleAddTask}
        >
          Add
        </button>
      </div>
      <ul>
        {tasks.map(task => (
          <ToDoItem 
            key={task.id}
            task={task}
            toggleComplete={toggleComplete}
            deleteTask={deleteTask}
            editTask={editTask}
          />
        ))}
      </ul>
    </div>
  );
}

export default ToDoList;
